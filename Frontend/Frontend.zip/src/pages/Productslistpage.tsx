/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/exhaustive-deps */
// src/pages/ProductsList/ProductsListPage.tsx
import { useState, useEffect } from "react";
import api from "../services/api";
import Header from "../components/header";
import "./ProductsListPage.css";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  status: string;
  mainImage?: string;
  seller: {
    id: number;
    firstName: string;
    lastName: string;
  };
  views: number;
  rating: number;
}

function ProductsListPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  useEffect(() => {
    fetchProducts();
  }, [category]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (category) params.category = category;
      if (search) params.search = search;

      const response = await api.get("/products", { params });
      setProducts(response.data.data);
      setError("");
    } catch (err: any) {
      setError(
        err.response?.data?.message || "Erreur lors du chargement des produits",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProducts();
  };

  return (
    <div className="products-list-page">
      <Header />

      <div className="products-list-container">
        {/* En-tête */}
        <div className="page-header">
          <h1>🛍️ Tous les Produits</h1>
          <p className="page-subtitle">Découvrez notre sélection de produits</p>
        </div>

        {/* Filtres */}
        <div className="filters-section">
          <form onSubmit={handleSearch} className="search-form">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="🔍 Rechercher un produit..."
              className="search-input"
            />
            <button type="submit" className="btn-search">
              Rechercher
            </button>
          </form>

          <div className="category-filter">
            <label htmlFor="category">Catégorie :</label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="category-select"
            >
              <option value="">Toutes les catégories</option>
              <option value="electronics">Électronique</option>
              <option value="clothing">Vêtements</option>
              <option value="food">Alimentation</option>
              <option value="books">Livres</option>
              <option value="home">Maison</option>
              <option value="sports">Sports</option>
              <option value="beauty">Beauté</option>
              <option value="toys">Jouets</option>
              <option value="other">Autre</option>
            </select>
          </div>
        </div>

        {/* Message d'erreur */}
        {error && (
          <div className="error-message">
            <span className="error-icon">⚠</span>
            {error}
          </div>
        )}

        {/* Chargement */}
        {loading && (
          <div className="loading-message">
            <div className="loading-spinner"></div>
            <p>Chargement des produits...</p>
          </div>
        )}

        {/* Message vide */}
        {!loading && products.length === 0 && (
          <div className="empty-message">
            <p style={{ fontSize: "3rem", margin: "0 0 10px 0" }}>🔭</p>
            <p style={{ margin: 0 }}>Aucun produit trouvé.</p>
            <p style={{ margin: "5px 0 0 0", fontSize: "14px" }}>
              Essayez de modifier vos critères de recherche.
            </p>
          </div>
        )}

        {/* Grille de produits */}
        <div className="products-grid">
          {products.map((product) => (
            <div key={product.id} className="product-card">
              {product.mainImage ? (
                <img
                  src={product.mainImage}
                  alt={product.name}
                  className="product-image"
                />
              ) : (
                <div className="product-image-placeholder">🖼️</div>
              )}

              <div className="product-content">
                <h3 className="product-name">{product.name}</h3>
                <p className="product-description">
                  {product.description || "Aucune description disponible"}
                </p>

                <div className="product-seller">
                  <span>Vendu par : </span>
                  <strong>
                    {product.seller.firstName} {product.seller.lastName}
                  </strong>
                </div>

                <div className="product-info">
                  <div>
                    <div className="product-price">
                      {product.price.toFixed(2)} TND
                    </div>
                    <div
                      className={`product-stock ${product.stock > 0 ? "stock-available" : "stock-unavailable"}`}
                    >
                      {product.stock > 0
                        ? `✓ En stock (${product.stock})`
                        : "✗ Rupture de stock"}
                    </div>
                  </div>
                </div>

                <div className="product-meta">
                  <span>👁️ {product.views} vues</span>
                  <span>⭐ {product.rating.toFixed(1)}</span>
                </div>

                <button className="btn-add-cart" disabled={product.stock === 0}>
                  🛒 Ajouter au panier
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ProductsListPage;
